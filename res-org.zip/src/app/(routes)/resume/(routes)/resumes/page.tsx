"use client";

import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Grid } from "@/components/ui/grid";
import { InfoIcon, Loader2, PlusIcon } from "lucide-react";
import Link from "next/link";
import axios from "axios";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ResumeCard } from "@/components/main/dashboard/resumes/card";
import useResumes from "@/app/hooks/get-resumes";
import { IResume } from "@/models/resume";

type SortOption = "name" | "date" | "views";

export default function ResumesPage() {
  const { resumes, loadingResumes, fetchResumes } = useResumes();
  const [selectedResumes, setSelectedResumes] = useState<string[]>([]);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<SortOption>("date");
  const [filterFolder, setFilterFolder] = useState("all");
  const { toast } = useToast();

  const confirmDelete = async () => {
    setIsDeleting(true);
    try {
      const response = await axios.post("/api/resume", {
        selectedResumes,
        operation: "delete",
      });
      if (response.status === 200) {
        fetchResumes();
        setSelectedResumes([]);
        setIsDeleteDialogOpen(false);
        toast({
          title: "Success",
          description: `Successfully deleted ${response.data.deletedCount} resume(s)`,
        });
      }
    } catch (error) {
      console.error("Error deleting resumes:", error);
      toast({
        title: "Error",
        description: "Failed to delete selected resumes. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredAndSortedResumes = useMemo(() => {
    return resumes
      ?.filter((resume: IResume) => {
        const matchesSearch = resume?.title
          .toLowerCase()
          .includes(searchQuery.toLowerCase());
        const matchesFolder =
          filterFolder === "all" || resume.tags.includes(filterFolder);

        return matchesSearch && matchesFolder;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "name":
            return a.title.localeCompare(b.title);
          case "date":
            return (
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );
          case "views":
            return b.analytics.views - a.analytics.views;
          default:
            return 0;
        }
      });
  }, [resumes, searchQuery, filterFolder, sortBy]);

  if (loadingResumes) {
    return <ResumeCardSkeleton />;
  }

  const tags = [];
  resumes.map((item) => {
    if (item.tags.length != 0) {
      item.tags.forEach((tag) => {
        tags.push(tag);
      });
    }
  });

  console.log(filterFolder);

  return (
    <div className="space-y-6 p-3">
      <div>
        <h2 className="text-2xl  font-bold tracking-tight">Resumes</h2>
        <p className="text-muted-foreground text-sm">
          List of all your resumes
        </p>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Link href="/resume/upload">
            <Button>
              <PlusIcon className="mr-2 h-4 w-4" />
              Upload New Resume
            </Button>
          </Link>
        </div>
      </div>
      {resumes?.length > 0 && (
        <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search resumes..."
            className="max-w-sm"
          />
          <div className=" flex items-center gap-x-2">
            <Select value={filterFolder} onValueChange={setFilterFolder}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by folder" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tags</SelectItem>
                {tags.map((item) => (
                  <SelectItem key={item} value={item}>
                    {item}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={sortBy}
              onValueChange={(value) => setSortBy(value as SortOption)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="date">Upload Date</SelectItem>
                <SelectItem value="views">Most Views</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {filteredAndSortedResumes?.length === 0 ? (
        <div className=" p-4 rounded-md flex items-center ">
          <InfoIcon className="mr-2" size={18} />
          <p>{searchQuery ? "No matching resumes found" : "No resumes yet"}</p>
        </div>
      ) : (
        <Grid className="gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {filteredAndSortedResumes?.map((resume) => (
            <ResumeCard
              key={resume?.shortUrl}
              resume={resume}
              searchQuery={searchQuery}
            />
          ))}
        </Grid>
      )}

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Are you sure you want to delete the selected resumes?
            </DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete the
              selected resumes.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ResumeCardSkeleton() {
  return (
    <>
      <div className=" p-3">
        <div className=" h-10 w-60  bg-muted rounded-lg animate-pulse"></div>
        <div className=" flex items-center gap-x-4 mt-5">
          <div className=" w-96 h-10 bg-muted rounded-lg animate-pulse"></div>
          <div className=" w-52 h-10 bg-muted rounded-lg animate-pulse"></div>
          <div className=" w-52 h-10 bg-muted rounded-lg animate-pulse"></div>
        </div>
      </div>
      <Grid className="gap-4 mt-3 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 p-3">
        {[...Array(6)].map((_, index) => (
          <div key={index} className="space-y-3">
            <div className="w-full h-40 bg-muted rounded-lg animate-pulse" />
          </div>
        ))}
      </Grid>
    </>
  );
}
