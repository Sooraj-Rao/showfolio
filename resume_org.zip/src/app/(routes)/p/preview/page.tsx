"use client";
import PortfolioParentPage from "@/app/(routes)/p/[username]/page";
import React from "react";

const Page = () => {
  return <PortfolioParentPage analytics={false} />;
};

export default Page;
