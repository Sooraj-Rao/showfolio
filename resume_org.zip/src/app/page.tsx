import { LandingPage } from "@/components/main/home/landing";
import React from "react";

const page = () => <LandingPage />;

export default page;
